define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    splitByPipe(strInput) {
      return (strInput.split("|"));
    }
    setComponentRequiredFlag(strInput) {
      document.getElementById(strInput).ariaRequired = true;
    }
    resetComponentToEmpty(strInput) {
      document.getElementById(strInput).value = "";
    }
  }
  PageModule.prototype.numValidator = function () {
    return [{
      type: 'regExp',
      options: {
        pattern: "[0-9]*",
        hint: "enter a valid number",
        messageDetail: "Not a valid number format"
      }
    }];

  };
  PageModule.prototype.emailValidator = function () {
    return [{
      type: 'regExp',
      options: {
        pattern: "^([a-z][a-z0-9_.]+@([a-z0-9-]+\.)+[a-z]{2,6}(, )*)+$",
        hint: "enter a valid email",
        messageDetail: "Not a valid email format"
      }
    }];

  };
  return PageModule;
});
