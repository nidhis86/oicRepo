define([], () => {
  'use strict';

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    ClearFields(arg1) {
       document.getElementById("ProcessName").value="";
    }
  }
  
  return PageModule;
});
