define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.dateToday = function () {
    return (new Date()).toISOString().split('T')[0];
  };

  PageModule.prototype.dateMinus24Hr = function () {
    return (new Date(new Date().getTime() - (24 * 60 * 60 * 1000))).toISOString().split('T')[0];
  };

  PageModule.prototype.isAnyRecordSelected = function (tableData) {
    var newTableData = JSON.parse(JSON.stringify(tableData));
    var isRecordSelected = false;

    for (var i = 0; i < newTableData.length; i++) {
      if (newTableData[i].select === true && newTableData[i].select != null) {
        isRecordSelected = true;
        break;
      }
    }
    return isRecordSelected;
  };

  PageModule.prototype.getSelectedRunIds = function (tableData) {
    var newTableData = JSON.parse(JSON.stringify(tableData));
    var selectedRunIds = [];

    for (var i = 0; i < newTableData.length; i++) {
      if (newTableData[i].select === true && newTableData[i].select != null) {
        // selectedRunIds = newTableData[i].run_id + "," + selectedRunIds;
        selectedRunIds.push({
          run_id: newTableData[i].run_id, sequence_id: newTableData[i].sequence_id,
          process_name: newTableData[i].process_name, payload: newTableData[i].payload,
          headers: newTableData[i].headers, http_method: newTableData[i].http_method,
          endpoint: newTableData[i].end_point, path_parameter: newTableData[i].path_parameter,
          reprocessing_flag: newTableData[i].reprocessing_flag, process_identifier: newTableData[i].process_identifier
        });
      }
    }

    return selectedRunIds;
  };

  PageModule.prototype.validatePayload = function (newPayload, endpoint) {
    if (endpoint.includes('/ic/api/')) {
      try {
        JSON.parse(newPayload);
        return "VALID";
      } catch (e) {
        return "Error in parsing payload :" + e;
      };
    }
    if (endpoint.includes('/ic/ws/')) {
      return "VALID";
    }
  };

  PageModule.prototype.disableComponentsOnReprocess = function (index) {
    document.getElementById('oj-button-reprocess-' + index).disabled = true;
    document.getElementById('oj-text-area-reprocess-' + index).disabled = true;
  };

  PageModule.prototype.reProcessInstance = async function (endpoint, newPayload, newHeaders, queryParameter, httpMethod, auth, authType) {
    if (endpoint.includes('/ic/api/')) {
      var reprocessedInstanceDetails = [];
      reprocessedInstanceDetails = await this.reprocessRest(endpoint, newPayload, newHeaders, queryParameter, httpMethod, auth, authType);
      return reprocessedInstanceDetails;
    }
    if (endpoint.includes('/ic/ws/')) {
      var reprocessedSoapInstanceDetails = [];
      reprocessedSoapInstanceDetails = await this.reprocessSoap(endpoint, newPayload, newHeaders, auth); 
      return reprocessedSoapInstanceDetails;
    }
  };

  PageModule.prototype.reprocessRest = async function (endpoint, newPayload, newHeaders, queryParameter, httpMethod, auth, authType) {
    var endpointVar = endpoint;
    var jsonVar = JSON.stringify(newPayload);
    var reprocessedInstanceDetails = [];
    var headerVar = [];
    const headers = new Headers();

    if (queryParameter != "" && queryParameter != null) {
      endpointVar = endpoint + queryParameter;
    }

    function setHeader(value) {
      var headerValue = [];
      headerValue = value.split("|");
      headers.append(headerValue[0], headerValue[1]);
    }

    if (newHeaders != "" && newHeaders != null) {
      headerVar = newHeaders.split(',');
      headerVar.forEach(setHeader);
    }

    if (authType == "Basic") {
      headers.append('Authorization', 'Basic '+ auth);
    } 
      
    if (authType == "OAuth2") {
      headers.append('Authorization', 'Bearer '+ auth);
    }

    const response = await (fetch(endpointVar, {
      method: httpMethod,
      body: newPayload,
      headers: headers
    }));

    if (response.ok) {
      reprocessedInstanceDetails.push({
        reprocessedInstanceId: response.headers.get('x-oracle-ics-instance-id'), status: "SUCCESS",
        statusCode: response.status, statusText: response.statusText
      });
      return reprocessedInstanceDetails;
    } else {
      reprocessedInstanceDetails.push({
        reprocessedInstanceId: response.headers.get('x-oracle-ics-instance-id'), status: "ERROR",
        statusCode: response.status, statusText: response.statusText, responseJSON: response.json()
      });
      return reprocessedInstanceDetails;
    }
  };

  PageModule.prototype.reprocessSoap = async function (endpoint, newPayload, newHeaders, auth) {
    var endpointVar = endpoint;
    var reprocessedSoapInstanceDetails = [];
    var headerVar = [];
    const headers = new Headers();

    function setHeader(value) {
      var headerValue = [];
      headerValue = value.split("|");
      headers.append(headerValue[0], headerValue[1]);
    }
    if (newHeaders != "" && newHeaders != null) {
      headerVar = newHeaders.split(',');
      headerVar.forEach(setHeader);
    }

    headers.append('Authorization', 'Basic '+ auth);
    const response = await (fetch(endpointVar, {
      body: newPayload,
      method: 'POST',
      headers: headers
    }));

    if (response.ok) {
      reprocessedSoapInstanceDetails.push({
        reprocessedInstanceId: response.headers.get('X-ORACLE-DMS-ECID'), status: "SUCCESS",
        statusCode: response.status, statusText: response.statusText
      });
      return reprocessedSoapInstanceDetails;
    } else {
      reprocessedSoapInstanceDetails.push({
        reprocessedInstanceId: response.headers.get('X-ORACLE-DMS-ECID'), status: "ERROR",
        statusCode: response.status, statusText: response.statusText
      });
      return reprocessedSoapInstanceDetails;
    }
  };

  PageModule.prototype.reprocessCustomActionBackup = function (endpoint, newPayload, newHeaders, queryParameter, httpMethod) {

    const url = 'https://cxintegrationinstance-orasenatdoracledigital01-ia.integration.ocp.oraclecloud.com:443/ic/api/integration/v1/flows/rest/POC_GENERATEERROR/2.0/error';
    var reprocessedInstanceId;
    var headerVar = 'Content-Type|application/json;customHeader|hello';
    var queryVar = 'q=1&count=10';
    var jsonVar;
    const jsonPayload = JSON.stringify({ "errorCode": "Sample" });
    var headers = [];
    if (headerVar != "") {
      headers = headerVar.split(',');
    }

    console.log('$$$$$ 1');
    var myPromise = new Promise(function (resolve) {
      console.log('$$$$$ 2');
      let request = new XMLHttpRequest();
      request.open("POST", url);
      jsonVar = jsonPayload;
      function setHeader(value) {
        var headerValue = [];
        headerValue = value.split("|");
        request.setRequestHeader(headerValue[0], headerValue[1]);
      }
      if (headerVar != "") {
        headers.forEach(setHeader);
      }
      console.log('$$$$$ 3');
      request.onload = function () {
        if (request.DONE) {
          console.log('$$$$$ 4');
          resolve(request.getResponseHeader('x-oracle-ics-instance-id'));
        } else {
          console.log('$$$$$ 5');
          resolve("Error");
        }
      };
      console.log('$$$$$ 6');
      request.setRequestHeader('Authorization', 'Basic T0lDVGVzdFVzZXI6RmVicnVhcnlAMjAyMw==');
      request.send(jsonVar);
    });

    myPromise.then(function (result) {
      if (result != 'Error') {
        console.log('Success: ' + result);
      }
    });
  };

  return PageModule;
});
